// app/gql/mutations/addToCart.ts
import { gql } from 'graphql-request';

export const addToCartMutation = gql`
  mutation addToCart($input: AddToCartInput!) {
    addToCart(input: $input) {
      cartItem {
        key
        quantity
        product {
          node {
            sku
            slug
            name
          }
        }
        variation {
          node {
            name
            databaseId
            salePrice(format: RAW)
            regularPrice(format: RAW)
            stockQuantity
            stockStatus
            image {
              sourceUrl(size: WOOCOMMERCE_THUMBNAIL)
            }
          }
          attributes {
            value
          }
        }
      }
    }
  }
`;
